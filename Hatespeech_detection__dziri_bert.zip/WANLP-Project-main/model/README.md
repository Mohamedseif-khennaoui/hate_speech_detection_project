# Model Execution Instructions

This project contains two main models that must be executed in sequence for proper functionality.

## 1. `dziri_binary_final`
This is the base model trained using the following datasets:
- `hate_final.csv`
- `normal_final.csv`

**Steps:**
1. Ensure all dependencies are installed.
2. Execute the `dziri_binary_final` model first, as it serves as the foundation for subsequent models.

## 2. `lora_dziri_final`
After executing the base model, proceed with the `lora_dziri_final` model. This model is trained using the following datasets:
- `nohate_balance`
- `hate_balance`
- `balanced_soft_vote`

**Steps:**
1. Confirm that `dziri_binary_final` has been executed successfully.
2. Run the `lora_dziri_final` model to complete the process.

Follow the above steps in order to ensure proper execution and results.

You can still find the models in this drive if you just want to download the final product and use it:
- [Base Model (`dziri_binary_final`)](https://drive.google.com/drive/folders/1605F74hfUk_u9llULpVqkqYP1JTvPR-R?usp=sharing)
- [LoRA Adapters (`lora_dziri_final`)](https://drive.google.com/drive/folders/1Cko0sAft-glMrVdp8JevQyR0fEzLQI0-?usp=sharing)
