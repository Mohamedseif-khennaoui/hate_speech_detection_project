# import os
# from dotenv import load_dotenv

# load_dotenv()

# MODEL_NAME = os.getenv("MODEL_NAME", "model_name")
