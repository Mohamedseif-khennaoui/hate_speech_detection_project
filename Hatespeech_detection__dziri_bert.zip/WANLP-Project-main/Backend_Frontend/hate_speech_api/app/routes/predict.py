from app.models.model_loader import predict_hate_speech
from pydantic import BaseModel
from fastapi import APIRouter

router = APIRouter()

class TextInput(BaseModel):
    text: str
    language: str = "en"  

@router.post("/predict/")
def predict_text(input: TextInput):
    # Pass both text and language to the prediction function
    result = predict_hate_speech(input.text, input.language)
    return {"text": input.text, "prediction": result}
