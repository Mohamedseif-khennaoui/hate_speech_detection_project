import re
import torch
import google.generativeai as genai
from transformers import AutoModelForSequenceClassification, AutoTokenizer
from peft import PeftModel

# Configure Gemini API
genai.configure(api_key="AIzaSyCupsPTvx4YJ-tn28h1YaKaEcoZ7h2GNt4")

# Paths
BASE_MODEL_PATH = r"C:\Users\hp\Downloads\dziri_binary_final\dziri_binary_final"  # base model
LORA_MODEL_PATH = r"C:\Users\hp\Downloads\dziri_binary_final\dziri_lora_2"  # lora adapter

def load_model():
    print(f"Loading base model from: {BASE_MODEL_PATH}")
    try:
        # 1. Load your old fully fine-tuned Dziri model
        model = AutoModelForSequenceClassification.from_pretrained(BASE_MODEL_PATH, local_files_only=True)
        
        # 2. Load and apply LoRA
        model = PeftModel.from_pretrained(model, LORA_MODEL_PATH, local_files_only=True)

        # ✨ 3. MERGE the LoRA weights into the model (important!)
        model = model.merge_and_unload()
        
        # 4. Load tokenizer (from base)
        tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_PATH, local_files_only=True)
        
        print("Model with merged LoRA loaded successfully!")
        return model, tokenizer
    except Exception as e:
        print(f"Error while loading model: {e}")
        raise e

model, tokenizer = load_model()

def extract_info_from_text_with_countries(response_text, language="en"):
    """Extract type, description, and countries from raw text using regex based on language."""
    if language == "en":
        type_pattern = re.search(r"(?i)Type\s*:\s*(.+)", response_text)
        description_pattern = re.search(r"(?i)Description\s*:\s*(.+)", response_text)
        countries_pattern = re.search(r"(?i)Countries\s*:\s*(.+)", response_text)
        default_type = "Not specified"
        default_description = "No description available"
    elif language == "ar":
        type_pattern = re.search(r"(?i)النوع\s*:\s*(.+)", response_text)
        description_pattern = re.search(r"(?i)الوصف\s*:\s*(.+)", response_text)
        countries_pattern = re.search(r"(?i)الدول\s*:\s*(.+)", response_text)
        default_type = "غير محدد"
        default_description = "لا يوجد وصف متاح"
    elif language == "fr":
        type_pattern = re.search(r"(?i)Type\s*:\s*(.+)", response_text)
        description_pattern = re.search(r"(?i)Description\s*:\s*(.+)", response_text)
        countries_pattern = re.search(r"(?i)Pays\s*:\s*(.+)", response_text)
        default_type = "Non spécifié"
        default_description = "Aucune description disponible"
    else:
        # Default to English
        type_pattern = re.search(r"(?i)Type\s*:\s*(.+)", response_text)
        description_pattern = re.search(r"(?i)Description\s*:\s*(.+)", response_text)
        countries_pattern = re.search(r"(?i)Countries\s*:\s*(.+)", response_text)
        default_type = "Not specified"
        default_description = "No description available"
    
    extracted_type = type_pattern.group(1).strip() if type_pattern else default_type
    extracted_description = (
        description_pattern.group(1).strip()
        if description_pattern
        else default_description
    )
    
    # Extract countries
    countries = []
    if countries_pattern:
        countries_text = countries_pattern.group(1).strip()
        # Split by commas and clean up each country name
        countries = [country.strip() for country in countries_text.split(',')]
    
    return extracted_type, extracted_description, countries


def classify_hate_speech(text, language="en"):
    """Send text to Gemini API and extract hate speech type, description, and countries in the specified language."""
    
    # Define prompts for different languages
    prompts = {
        "en": f"""
        Classify the following text as hate speech or not.
        If it is hate speech, identify the type of hate speech and provide a detailed explanation.
        Also, list 2-10 countries where this type of hate speech is commonly used.
        The text can be in 3 languages ONLY: Standard Arabic, Algerian Arabic, or Arabizi.
        Answer in English using the following format:
        
        Type: [Exact category of hate speech in 3 words max]
        Description: [Detailed explanation]
        Countries: [Comma-separated list of countries where this type of speech is common]
        
        Text: "{text}"
        """,
        
        "ar": f"""
        صنف النص التالي إذا كان خطاب كراهية أم لا.
        إذا كان خطاب كراهية، حدد نوع خطاب الكراهية وقدم شرحًا مفصلاً.
        أيضًا، اذكر 2-10 دول باللغة الانجليزية حيث يشيع استخدام هذا النوع من خطاب الكراهية.
        يمكن أن يكون النص بثلاث لغات فقط: العربية الفصحى، العربية الجزائرية، أو العربيزي.
        أجب باللغة العربية باستخدام التنسيق التالي:
        
        النوع: [فئة خطاب الكراهية بالضبط في 3 كلمات كحد أقصى]
        الوصف: [شرح مفصل]
        الدول: [قائمة دول مفصولة بفواصل حيث يشيع هذا النوع من الخطاب]
        
        النص: "{text}"
        """,
        
        "fr": f"""
        Classifiez le texte suivant comme discours haineux ou non.
        S'il s'agit d'un discours haineux, identifiez le type de discours haineux et fournissez une explication détaillée.
        Également, listez 2-10 pays dans la langue anglaise où ce type de discours haineux est couramment utilisé.
        Le texte peut être en 3 langues SEULEMENT: arabe standard, arabe algérien ou arabizi.
        Répondez en français en utilisant le format suivant:
        
        Type: [Catégorie exacte du discours haineux en 3 mots max]
        Description: [Explication détaillée]
        Pays: [Liste de pays séparés par des virgules où ce type de discours est courant]
        
        Texte: "{text}"
        """
    }
    
    # Use default English prompt if language not supported
    prompt = prompts.get(language, prompts["en"])
    
    try:
        response = genai.GenerativeModel("gemini-1.5-flash-002").generate_content(prompt)
        response_text = response.text.strip()
        return extract_info_from_text_with_countries(response_text, language)
    except Exception as e:
        print(f" Error with Gemini API: {e}")
        
        # Return error message in the appropriate language
        if language == "ar":
            return "خطأ", str(e), []
        elif language == "fr":
            return "Erreur", str(e), []
        else:
            return "Error", str(e), []


def extract_hate_words(text, threshold=0.5):
    """Breaks text into words and returns words with high hate confidence."""
    words = text.split()
    hate_words = []
    
    for word in words:
        inputs = tokenizer(word, return_tensors="pt", truncation=True, padding=True).to(model.device)
        
        with torch.no_grad():
            outputs = model(**inputs)
            probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
        
        hate_score = probs[0][1].item()
        if hate_score > threshold:
            hate_words.append({
                "word": word,
                "confidence": hate_score
            })
    
    return hate_words

def highlight_hate_words(text, hate_words):
    if not hate_words:
         return f"<span style='background-color: #BC3F5C'>{text}</span>"
        
    pattern = "(" + "|".join(re.escape(word["word"]) for word in hate_words) + ")"
    
    def replacer(match):
        word = match.group(0)
        return f"<span style='background-color: #BC3F5C'>{word}</span>"
    
    return re.sub(pattern, replacer, text)

def calculate_hate_percentage(text, hate_words):
    total_words = len(text.split())
    return round(len(hate_words) / total_words * 100, 2) if total_words > 0 else 0.0

def get_no_hate_speech_message(language):
    """Return appropriate 'no hate speech' message based on language."""
    if language == "ar":
        return "لا يوجد خطاب كراهية", "لا يوجد خطاب كراهية في هذا النص.", []
    elif language == "fr":
        return "Pas de discours haineux", "Il n'y a pas de discours haineux dans ce texte.", []
    else:  # Default to English
        return "No hate speech", "There is no hate speech in this text.", []



def predict_hate_speech(text, language="en"):
    """Predict if text is hate speech and determine its type and countries."""
    if not text:
        return {
            "error": "Text cannot be empty"
        }
    
    inputs = tokenizer(
        text, return_tensors="pt", truncation=True, padding=True, max_length=512
    )
    
    with torch.no_grad():
        outputs = model(**inputs)
        probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
    predicted_class = torch.argmax(probs, dim=-1).item()
    
    # Extract confidence score for class "1" (hate speech)
    hate_confidence = probs[0][1].item()
    hate_confidence_percentage = round(hate_confidence * 100, 2)
    
    if predicted_class == 1:
        hate_type, description, countries = classify_hate_speech(text, language)
    else:
        hate_type, description, countries = get_no_hate_speech_message(language)
        countries = []
    
    # Word-level analysis
    hate_words = extract_hate_words(text)
    highlighted_html = highlight_hate_words(text, hate_words)
    hate_word_percentage = calculate_hate_percentage(text, hate_words)
    
    return {
        "text": text,
        "hate_speech": bool(predicted_class),
        "confidence": probs.tolist(),
        "type": hate_type,
        "description": description,
        "highlighted_html": highlighted_html,
        "hate_percentage": hate_word_percentage,
        "hate_confidence_percentage": hate_confidence_percentage,
        "countries": countries  
    }
