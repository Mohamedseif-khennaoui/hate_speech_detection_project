import google.generativeai as genai

genai.configure(api_key="AIzaSyAXA16B6rjzgkmPw9lIApoYJyWPY4sL0CI")

models = genai.list_models()
for model in models:
    print(model.name)  # Affiche tous les modèles disponibles
