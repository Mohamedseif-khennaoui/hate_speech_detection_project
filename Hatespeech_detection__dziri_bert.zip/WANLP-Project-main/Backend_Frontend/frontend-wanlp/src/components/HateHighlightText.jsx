import React from 'react';
import { Box, Typography, Paper } from '@mui/material';

const HateHighlightText = ({ htmlText }) => {
  if (!htmlText) return null;

  return (
    <Box p={2}
    elevation={0}
    sx={{
      p: 2.5,
      borderRadius: 3,
      direction: 'rtl', // For Arabic text
      textAlign: 'right',
      color: '#FFFFFF' // White text
    }}>
        <Typography 
          variant="body1" 
          component="div" 
          sx={{ 
            lineHeight: 1.8,
            '& span[style*="background-color: yellow"]': {
              backgroundColor: 'rgba(255, 82, 82, 0.3) !important', // Override yellow highlighting
              color: '#FFFFFF !important',
              padding: '0 4px',
              borderRadius: '3px'
            }
          }}
        >
          <div dangerouslySetInnerHTML={{ __html: htmlText }} />
        </Typography>
        
        <Box 
          mt={2} 
          pt={2} 
          borderTop="1px solid rgba(47, 80, 159, 0.3)" 
          display="flex" 
          justifyContent="flex-end"
          direction="ltr"
        >
          <Box 
            display="flex" 
            alignItems="center" 
            sx={{ 
              bgcolor: 'rgba(255, 82, 82, 0.15)', 
              px: 1.5, 
              py: 0.5,
              borderRadius: 2
            }}
          >
            <Box 
              sx={{ 
                width: 12, 
                height: 12, 
                bgcolor: '#FF5252', // Error color
                borderRadius: '50%',
                mr: 1
              }} 
            />
            <Typography variant="caption" fontWeight="medium" color="#FFFFFF">
              potential hate words
            </Typography>
          </Box>
        </Box>
    </Box>
  );
};

export default HateHighlightText;