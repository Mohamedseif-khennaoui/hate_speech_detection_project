import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Box } from '@mui/material';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend);

const DoughnutChartComp = ({ confidenceData, labels }) => {
  const data = {
    labels: labels || ['Hate Speech', 'No Hate Speech'],
    datasets: [
      {
        data: confidenceData,
        backgroundColor: ['rgba(255, 99, 132, 0.7)', 'rgba(75, 192, 192, 0.7)'],
        borderColor: ['rgba(255, 99, 132, 1)', 'rgba(75, 192, 192, 1)'],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: true,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          boxWidth: 15,
          padding: 15,
          font: {
            size: 13
          }
        }
      },
    }
  };

  return (
    <Box sx={{
      width: '100%',
      maxWidth: '250px',
      margin: '0 auto',
      textAlign: 'center'
    }}>
      <Doughnut data={data} options={options} />
    </Box>
  );
};

export default DoughnutChartComp;
