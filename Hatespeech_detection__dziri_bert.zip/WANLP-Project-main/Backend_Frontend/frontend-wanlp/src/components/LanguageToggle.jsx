import React, { useState } from 'react';
import { 
  IconButton, 
  Menu, 
  MenuItem, 
  Tooltip, 
  ListItemIcon, 
  ListItemText,
  Typography
} from '@mui/material';
import { Translate } from '@mui/icons-material';
import { useLanguage } from '../contexts/LanguageContext';

const LanguageToggle = () => {
  const { language, changeLanguage, availableLanguages, t } = useLanguage();
  const [anchorEl, setAnchorEl] = useState(null);
  
  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };
  
  const handleMenuClose = () => {
    setAnchorEl(null);
  };
  
  const handleLanguageChange = (lang) => {
    changeLanguage(lang);
    handleMenuClose();
  };
  
  const languageNames = {
    en: 'English',
    ar: 'العربية',
    fr: 'Français'
  };

  const languageFlags = {
    en: '🇺🇸',
    ar: '🇩🇿',
    fr: '🇫🇷'
  };

  return (
    <>
      <Tooltip title={t('language')}>
        <IconButton
          onClick={handleMenuOpen}
          color="primary"
          sx={{ 
            borderRadius: 2,
            '&:hover': {
              backgroundColor: 'rgba(63, 81, 181, 0.08)'
            }
          }}
        >
          <Translate />
          <Typography 
            variant="body2" 
            sx={{ 
              ml: 0.5, 
              fontWeight: 'medium',
              display: { xs: 'none', sm: 'block' }
            }}
          >
            {languageNames[language]}
          </Typography>
        </IconButton>
      </Tooltip>
      
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
        PaperProps={{
          elevation: 3,
          sx: {
            borderRadius: 2,
            minWidth: 180,
            overflow: 'visible',
            mt: 1.5,
            '& .MuiMenuItem-root': {
              px: 2,
              py: 1.5,
              borderRadius: 1,
              mx: 0.5,
              my: 0.25
            }
          }
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        {availableLanguages.map((lang) => (
          <MenuItem
            key={lang}
            onClick={() => handleLanguageChange(lang)}
            selected={language === lang}
            sx={{
              fontWeight: language === lang ? 'bold' : 'regular',
            }}
          >
            <ListItemIcon sx={{ minWidth: 36 }}>
              {languageFlags[lang]}
            </ListItemIcon>
            <ListItemText primary={languageNames[lang]} />
          </MenuItem>
        ))}
      </Menu>
    </>
  );
};

export default LanguageToggle;
