import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, GeoJSON } from 'react-leaflet';
import { Box, Typography, Paper, alpha, useTheme, CircularProgress } from '@mui/material';
import { motion } from 'framer-motion';
import 'leaflet/dist/leaflet.css';

const CountryHighlightMap = ({ 
  countryNames = [], 
  title = "Geographic Distribution"
}) => {
  const theme = useTheme();
  const [geoJsonData, setGeoJsonData] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // Fetch GeoJSON data for countries
  useEffect(() => {
    fetch('https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world.geojson')
      .then(response => response.json())
      .then(data => {
        setGeoJsonData(data);
        setLoading(false);
      })
      .catch(error => {
        console.error("Error loading GeoJSON data:", error);
        setLoading(false);
      });
  }, []);
  
  // Style function for GeoJSON features
  const getCountryStyle = (feature) => {
    // Check if this country should be highlighted
    const countryName = feature.properties.name;
    const isHighlighted = countryNames.some(name => 
      countryName.toLowerCase().includes(name.toLowerCase()) || 
      name.toLowerCase().includes(countryName.toLowerCase())
    );
    
    if (!isHighlighted) {
      return {
        fillColor: theme.palette.grey[300],
        weight: 1,
        opacity: 0.5,
        color: theme.palette.grey[500],
        fillOpacity: 0.2
      };
    }
    
    // Highlighted country style
    return {
      fillColor: theme.palette.error.main,
      weight: 2,
      opacity: 1,
      color: theme.palette.common.white,
      fillOpacity: 0.7
    };
  };
  
  // Function to handle each feature
  const onEachFeature = (feature, layer) => {
    const countryName = feature.properties.name;
    const isHighlighted = countryNames.some(name => 
      countryName.toLowerCase().includes(name.toLowerCase()) || 
      name.toLowerCase().includes(countryName.toLowerCase())
    );
    
    if (isHighlighted) {
      // Add a popup with ONLY the country name
      layer.bindPopup(`<b>${countryName}</b>`);
      
      // Add hover effect
      layer.on({
        mouseover: (e) => {
          const layer = e.target;
          layer.setStyle({
            weight: 3,
            fillOpacity: 0.9
          });
          layer.openPopup();
        },
        mouseout: (e) => {
          const layer = e.target;
          layer.setStyle({
            weight: 2,
            fillOpacity: 0.7
          });
          layer.closePopup();
        }
      });
    }
  };
  
  // Sample countries for demo if none provided
  const sampleCountries = ['United States', 'Brazil', 'South Africa', 'Australia', 'India', 'France'];
  const countriesToDisplay = countryNames.length > 0 ? countryNames : sampleCountries;
  
  return (
    <Paper 
      elevation={2} 
      sx={{ 
        p: 2, 
        borderRadius: 2,
        bgcolor: alpha(theme.palette.background.paper, 0.7),
        overflow: 'hidden'
      }}
    >
      <Typography variant="h6" gutterBottom>
        {title}
      </Typography>
      
      <Typography variant="body2" color="text.secondary" paragraph>
        Countries where this content is detected:
      </Typography>
      
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        style={{ height: 400, width: '100%' }}
      >
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
            <CircularProgress />
          </Box>
        ) : (
          <MapContainer 
            center={[20, 0]} 
            zoom={2} 
            style={{ height: '100%', width: '100%', borderRadius: '8px' }}
            scrollWheelZoom={true}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            {geoJsonData && (
              <GeoJSON 
                data={geoJsonData} 
                style={getCountryStyle}
                onEachFeature={onEachFeature}
              />
            )}
          </MapContainer>
        )}
      </motion.div>
      
      <Box sx={{ display: 'flex', alignItems: 'center', mt: 2, justifyContent: 'center' }}>
        <Box 
          sx={{ 
            width: 12, 
            height: 12, 
            borderRadius: '50%', 
            bgcolor: theme.palette.error.main,
            mr: 1 
          }} 
        />
        <Typography variant="caption">Highlighted Countries</Typography>
      </Box>
    </Paper>
  );
};

export default CountryHighlightMap;
