import React from 'react';
import { AppBar, Toolbar, Typography, Box, useTheme, useMediaQuery } from '@mui/material';
import LanguageToggle from './LanguageToggle';
import { useLanguage } from '../contexts/LanguageContext';
import logoImage from '../assets/Logo.png';

const Header = () => {
  const { t } = useLanguage();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  // Custom color palette
  const colors = {
    white: '#FFFFFF',
    black: '#141313',
    darkBlue: '#100C53',
    mediumBlue: '#2F509F',
    lightBlue: '#20E5F6'
  };
  
  return (
    <AppBar 
      position="static" 
      color="transparent" 
      elevation={0}
      sx={{
        backdropFilter: 'blur(10px)',
        backgroundColor: `${colors.white}`, 
        borderBottom: 2,
        borderColor: `${colors.mediumBlue}40`, 
        boxShadow: `0 4px 12px ${colors.darkBlue}15` 
      }}
    >
      <Toolbar>
        <Box 
          display="flex" 
          alignItems="center"
          sx={{
            flexGrow: 1
          }}
        >
          {/* Logo with responsive sizing */}
          <Box 
            component="img"
            src={logoImage}
            alt="DZ SafeText Logo"
            sx={{
              height: isMobile ? '32px' : '40px',
              marginRight: 2,
              transition: 'transform 0.3s ease',
              '&:hover': {
                transform: 'scale(1.05)'
              }
            }}
          />
          

        </Box>
        
        <LanguageToggle />
      </Toolbar>
    </AppBar>
  );
};

export default Header;
