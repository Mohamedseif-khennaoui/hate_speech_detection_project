import React from 'react';
import { Box, Typography, LinearProgress, Paper } from '@mui/material';
import { Warning, CheckCircle, ErrorOutline } from '@mui/icons-material';
import { useLanguage } from '../contexts/LanguageContext';

const HateStats = ({ percentage }) => {
  // Get translation function
  const { t } = useLanguage();

  // Determine severity level based on percentage
  const getSeverity = (percent) => {
    if (percent >= 70) return { 
      level: t('severityCritical'), 
      color: '#d32f2f', 
      icon: <ErrorOutline /> 
    };
    if (percent >= 40) return { 
      level: t('severityHigh'), 
      color: '#f44336', 
      icon: <Warning /> 
    };
    if (percent >= 20) return { 
      level: t('severityMedium'), 
      color: '#ff9800', 
      icon: <Warning /> 
    };
    if (percent > 0) return { 
      level: t('severityLow'), 
      color: '#4caf50', 
      icon: <CheckCircle /> 
    };
    return { 
      level: t('noHateSpeech'), 
      color: '#4caf50', 
      icon: <CheckCircle /> 
    };
  };

  const severity = getSeverity(percentage);

  return (
    <Box p={3}>
      <Paper 
        elevation={0}
        sx={{ 
          p: 2.5, 
          borderRadius: 3,
          bgcolor: 'rgba(0, 0, 0, 0.03)',
          border: '1px solid rgba(0, 0, 0, 0.08)'
        }}
      >
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
          <Typography variant="h6" fontWeight="bold">
            {t('hateSpeechSeverity')}
          </Typography>
          <Box 
            display="flex"
            alignItems="center"
            sx={{
              bgcolor: `${severity.color}20`,
              px: 2,
              py: 0.5,
              borderRadius: 2,
              color: severity.color
            }}
          >
            {severity.icon}
            <Typography variant="subtitle1" fontWeight="bold" ml={1}>
              {severity.level}
            </Typography>
          </Box>
        </Box>
        
        <Box mt={2}>
          <Box display="flex" justifyContent="space-between" mb={0.5}>
            <Typography variant="body2" color="text.secondary">
              {t('hateContent')}
            </Typography>
            <Typography variant="body2" fontWeight="bold">
              {percentage}%
            </Typography>
          </Box>
          <LinearProgress 
            variant="determinate"
            value={percentage}
            sx={{
              height: 10,
              borderRadius: 5,
              bgcolor: 'rgba(237, 221, 221, 0.29)',
              '& .MuiLinearProgress-bar': {
                bgcolor: severity.color,
                borderRadius: 5
              }
            }}
          />
        </Box>
        
        <Typography variant="body2" color="text.secondary" mt={2} textAlign="center">
          {percentage === 0
            ? t('noHateSpeechDetectedInText')
            : t('hateSpeechPercentageText').replace('{percentage}', percentage).replace('{severity}', severity.level.toLowerCase())}
        </Typography>
      </Paper>
    </Box>
  );
};

export default HateStats;
