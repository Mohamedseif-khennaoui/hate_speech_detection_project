import { createContext, useState, useContext, useEffect } from 'react';

// Define translations
const translations = {
  en: {
    title: "Algerian & Arabic Hate Speech Detector",
    welcome: "Welcome to",
    subtitle: "Analyze text for hate speech in Arabic and Algerian dialect",
    textFieldLabel: "Enter text to analyze...",
    analyzeButton: "Analyze Text",
    hateSpeechDetected: "Hate Speech Detected",
    noHateSpeechDetected: "No Hate Speech Detected",
    copyTooltip: "Copy results",
    copiedTooltip: "Copied!",
    categoryTitle: "Category",
    categoryTooltip: "The type of hate speech detected in the text",
    hateContentTitle: "Offensive Content Analysis",
    hateContentTooltip: "Percentage of hate speech content in the text",
    ofTextContains: "of the text contains hate speech",
    confidenceTitle: "Confidence Analysis",
    confidenceTooltip: "Model's confidence in the classification",
    hateContent: "Hate Content",
    normalContent: "Normal Content",
    explanationTitle: "Explanation",
    explanationTooltip: "Explanation of the hate speech detected",
    noExplanation: "No explanation available",
    highlightedTextTitle: "Potential suspecious words",
    highlightedTextTooltip: "Text with potential hate content highlighted",
    potentialHateWords: "Potential Suspecious Words",
    hateSpeech: "Hate Speech",
    noHateSpeech: "No Hate Speech",
    errorAnalysis: "Error during analysis. Please try again later.",
    emptyTextAlert: "Please enter some text to analyze.",
    language: "Language",
    hateSpeechSeverity: "Hate Speech Severity",
    severityLow: "Low Severity",
    severityMedium: "Medium Severity",
    severityHigh: "High Severity",
    severityCritical: "Critical Severity",
    noHateSpeechDetectedInText: "No hate speech detected in this text.",
    hateSpeechPercentageText: "{percentage}% of the text contains hate speech content. The severity level is {severity}.",
    geographicDistributionTitle: "Geographic Distribution",
    geographicDistributionTooltip: "Countries where this type of hate speech is commonly used",
    noCountriesAvailable: "No geographic data available for this content"
  },
  ar: {
    title: "كاشف خطاب الكراهية الجزائرية والعربية",
    welcome: "مرحبًا بك في",
    subtitle: "تحليل النص للكشف عن خطاب الكراهية باللغة العربية واللهجة الجزائرية",
    textFieldLabel: "أدخل النص للتحليل...",
    analyzeButton: "تحليل النص",
    hateSpeechDetected: "تم اكتشاف خطاب كراهية",
    noHateSpeechDetected: "لم يتم اكتشاف خطاب كراهية",
    copyTooltip: "نسخ النتائج",
    copiedTooltip: "تم النسخ!",
    categoryTitle: "الفئة",
    categoryTooltip: "نوع خطاب الكراهية المكتشف في النص",
    hateContentTitle: "تحليل محتوى الكراهية",
    hateContentTooltip: "نسبة محتوى خطاب الكراهية في النص",
    ofTextContains: "من النص يحتوي على خطاب كراهية",
    confidenceTitle: "تحليل الثقة",
    confidenceTooltip: "ثقة النموذج في التصنيف",
    hateContent: "محتوى كراهية",
    normalContent: "محتوى عادي",
    explanationTitle: "التفسير",
    explanationTooltip: "تفسير خطاب الكراهية المكتشف",
    noExplanation: "لا يوجد تفسير متاح",
    highlightedTextTitle: "الكلمات المثيرة للجدل",
    highlightedTextTooltip: "النص مع تمييز محتوى خطاب الكراهية",
    potentialHateWords: "الكلمات المثيرة للجدل",
    hateSpeech: "خطاب كراهية",
    noHateSpeech: "لا يوجد خطاب كراهية",
    errorAnalysis: "خطأ أثناء التحليل. يرجى المحاولة مرة أخرى لاحقًا.",
    emptyTextAlert: "الرجاء إدخال نص للتحليل.",
    language: "اللغة",
    hateSpeechSeverity: "شدة خطاب الكراهية",
    severityLow: "شدة منخفضة",
    severityMedium: "شدة متوسطة",
    severityHigh: "شدة عالية",
    severityCritical: "شدة حرجة",
    noHateSpeechDetectedInText: "لم يتم اكتشاف خطاب كراهية في هذا النص.",
    hateSpeechPercentageText: "{percentage}% من النص يحتوي على محتوى خطاب كراهية. مستوى الشدة هو {severity}.",
    geographicDistributionTitle: "التوزيع الجغرافي",
    geographicDistributionTooltip: "البلدان التي يستخدم فيها هذا النوع من خطاب الكراهية بشكل شائع",
    noCountriesAvailable: "لا توجد بيانات جغرافية متاحة لهذا المحتوى"
  },
  fr: {
    title: "Détecteur de Discours Haineux en Arabe et en Dialecte Algerien",
    welcome: "Bienvenue sur",
    subtitle: "Analyser le texte pour détecter les discours haineux en arabe et en dialecte algérien",
    textFieldLabel: "Entrez le texte à analyser...",
    analyzeButton: "Analyser le Texte",
    hateSpeechDetected: "Discours Haineux Détecté",
    noHateSpeechDetected: "Aucun Discours Haineux Détecté",
    copyTooltip: "Copier les résultats",
    copiedTooltip: "Copié!",
    categoryTitle: "Catégorie",
    categoryTooltip: "Le type de discours haineux détecté dans le texte",
    hateContentTitle: "Analyse du Contenu offensif",
    hateContentTooltip: "Pourcentage de contenu haineux dans le texte",
    ofTextContains: "du texte contient un discours haineux",
    confidenceTitle: "Analyse de Confiance",
    confidenceTooltip: "Confiance du modèle dans la classification",
    hateContent: "Contenu Haineux",
    normalContent: "Contenu Normal",
    explanationTitle: "Explication",
    explanationTooltip: "Explication du discours haineux détecté",
    noExplanation: "Aucune explication disponible",
    highlightedTextTitle: "Mots Surlignés",
    highlightedTextTooltip: "Texte avec contenu potentiellement haineux surligné",
    potentialHateWords: "Mots Potentiellement Suspects",
    hateSpeech: "Discours Haineux",
    noHateSpeech: "Pas de Discours Haineux",
    errorAnalysis: "Erreur lors de l'analyse. Veuillez réessayer plus tard.",
    emptyTextAlert: "Veuillez entrer un texte à analyser.",
    language: "Langue",
    hateSpeechSeverity: "Sévérité du Discours Haineux",
    severityLow: "Sévérité Faible",
    severityMedium: "Sévérité Moyenne",
    severityHigh: "Sévérité Élevée",
    severityCritical: "Sévérité Critique",
    noHateSpeechDetectedInText: "Aucun discours haineux détecté dans ce texte.",
    hateSpeechPercentageText: "{percentage}% du texte contient un discours haineux. Le niveau de sévérité est {severity}.",
    geographicDistributionTitle: "Distribution Géographique",
    geographicDistributionTooltip: "Pays où ce type de discours haineux est couramment utilisé",
    noCountriesAvailable: "Aucune donnée géographique disponible pour ce contenu"
  }
};

// Create context
const LanguageContext = createContext({
  language: 'en',
  t: (key) => key,
  changeLanguage: () => {},
  availableLanguages: ['en', 'ar', 'fr']
});

// Language provider component
export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(() => {
    // Try to get saved language from localStorage
    const savedLanguage = localStorage.getItem('preferredLanguage');
    return savedLanguage || 'en';
  });

  // Set document direction for RTL languages when language changes
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    // Save language preference to localStorage
    localStorage.setItem('preferredLanguage', language);
  }, [language]);

  const changeLanguage = (lang) => {
    setLanguage(lang);
  };

  // Translation function
  const t = (key) => {
    return translations[language][key] || key;
  };

  const contextValue = {
    language,
    t,
    changeLanguage,
    availableLanguages: ['en', 'ar', 'fr']
  };

  return (
    <LanguageContext.Provider value={contextValue}>
      {children}
    </LanguageContext.Provider>
  );
};

// Custom hook to use the language context
export const useLanguage = () => useContext(LanguageContext);