import { useState } from "react";
import {
  Button, TextField, Container, Typography, Paper,
  Box, CircularProgress, Card, CardContent, Divider,
  Tooltip, IconButton, Chip
} from "@mui/material";
import DoughnutChartComp from "../components/DoughnutChartComp";
import HateHighlightText from "../components/HateHighlightText";
import HateStats from "../components/HateStats";
import CountryHighlightMap from '../components/CountryHighlightMap';
import {
  WarningAmber, CheckCircle, Info, PieChart,
  ContentCopy, Category, BarChart, FormatQuote,
} from "@mui/icons-material";
import axios from "axios";
import { motion } from "framer-motion";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { useLanguage } from "../contexts/LanguageContext";

// Updated color palette with dark theme
const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: "#2F509F",
      light: "#20E5F6",
      dark: "#1A3370",
    },
    secondary: {
      main: "#20E5F6",
      light: "#65EEFF",
      dark: "#17B6C4",
    },
    error: {
      main: "#FF5252",
    },
    success: {
      main: "#4caf50",
    },
    warning: {
      main: "#ff9800",
    },
    text: {
      primary: "#FFFFFF",
      secondary: "#B8B8B8",
    },
    background: {
      default: "#100C53",
      paper: "#141313",
    },
  },
  typography: {
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    h3: {
      fontWeight: 700,
      color: "#FFFFFF",
    },
    h5: {
      fontWeight: 600,
      color: "#20E5F6",
    },
    h6: {
      fontWeight: 600,
      color: "#FFFFFF",
    },
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          boxShadow: "0 8px 40px rgba(0,0,0,0.3)",
          backgroundColor: "#141313",
        }
      }
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          textTransform: "none",
          fontWeight: 600,
          padding: "10px 24px"
        },
        containedPrimary: {
          background: "linear-gradient(135deg, #2F509F 0%, #20E5F6 100%)",
          "&:hover": {
            background: "linear-gradient(135deg, #3A61BD 0%, #57EEFF 100%)",
          }
        }
      }
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-root": {
            borderRadius: 12,
            backgroundColor: "#1E1E1E",
            "&.Mui-focused fieldset": {
              borderColor: "#20E5F6",
            },
            "& fieldset": {
              borderColor: "#2F509F",
            },
            "&:hover fieldset": {
              borderColor: "#20E5F6",
            }
          },
          "& .MuiInputLabel-root": {
            color: "#B8B8B8",
          },
          "& .MuiInputLabel-root.Mui-focused": {
            color: "#20E5F6",
          }
        }
      }
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          backgroundColor: "#141313",
        }
      }
    },
    MuiChip: {
      styleOverrides: {
        root: {
          fontWeight: 500,
        },
        colorPrimary: {
          backgroundColor: "#2F509F",
        }
      }
    },
    MuiDivider: {
      styleOverrides: {
        root: {
          backgroundColor: "rgba(255,255,255,0.1)",
        }
      }
    }
  }
});

// Custom styled components with dark theme colors
const GradientBackground = ({ children }) => (
  <Box
    sx={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #100C53 0%, #141313 100%)",
      py: 6
    }}
  >
    {children}
  </Box>
);

const ResultCard = ({ isHateSpeech, children }) => (
  <Card sx={{
    borderTop: `4px solid ${isHateSpeech ? "#FF5252" : "#4caf50"}`,
    transition: "all 0.3s ease-in-out",
    backgroundColor: "#141313",
    "&:hover": {
      boxShadow: "0 12px 48px rgba(0,0,0,0.5)"
    }
  }}>
    <CardContent sx={{ p: 0 }}>
      {children}
    </CardContent>
  </Card>
);

const SectionHeader = ({ icon, title, tooltip }) => (
  <Box display="flex" alignItems="center" gap={1} mb={1.5}>
    {icon}
    <Typography variant="h6" fontWeight="bold" color="#FFFFFF">{title}</Typography>
    {tooltip && (
      <Tooltip title={tooltip}>
        <Info fontSize="small" sx={{ color: "rgba(255,255,255,0.7)" }} />
      </Tooltip>
    )}
  </Box>
);

const Homepage = () => {
  const { t, language } = useLanguage();
  const [text, setText] = useState("");
  const [analysis, setAnalysis] = useState(null);
  const [category, setCategory] = useState("");
  const [explanation, setExplanation] = useState("");
  const [confidenceData, setConfidenceData] = useState([0, 0]);
  const [loading, setLoading] = useState(false);
  const [highlightedHTML, setHighlightedHTML] = useState("");
  const [hatePercentage, setHatePercentage] = useState(0);
  const [copied, setCopied] = useState(false);
  const [countries, setCountries] = useState([]);

  const handleAnalyze = async () => {
    if (!text.trim()) {
      alert(t('emptyTextAlert'));
      return;
    }
    
    setLoading(true);
    
    try {
      // Send the current language to the backend
      const response = await axios.post("http://localhost:8000/predict/", {
        text: text,
        language: language
      });
      
      const {
        hate_speech,
        type,
        description,
        highlighted_html,
        hate_percentage,
        hate_confidence_percentage,
        countries
      } = response.data.prediction;
      
      const hateConfidencePercentage = parseFloat(hate_confidence_percentage) || 0;
      const noHateConfidencePercentage = parseFloat((100 - hate_confidence_percentage).toFixed(2)) || 0;
      const result = hate_speech ? t('hateSpeechDetected') : t('noHateSpeechDetected');
      
      setAnalysis(result);
      setCategory(type || t('notSpecified'));
      setExplanation(description);
      setConfidenceData([hateConfidencePercentage, noHateConfidencePercentage]);
      setHighlightedHTML(highlighted_html || text);
      setHatePercentage(hate_percentage || 0);
      setCountries(countries || []);
    } catch (error) {
      console.error("Error during analysis:", error);
      setAnalysis(t('errorAnalysis'));
    } finally {
      setLoading(false);
    }
  };

  const handleCopyResults = () => {
    const result = `
      Text: ${text}
      Analysis: ${analysis}
      ${category ? `Category: ${category}` : ''}
      ${hatePercentage ? `Hate Speech Percentage: ${hatePercentage}%` : ''}
      ${explanation ? `Explanation: ${explanation}` : ''}
    `.trim();
    
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const isHateSpeech = analysis && analysis === t('hateSpeechDetected');
  
  return (
    <ThemeProvider theme={theme}>
      <GradientBackground>
        <Container maxWidth="md">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <Typography 
              variant="h3" 
              align="center"
              fontWeight="bold"
              sx={{ mb: 2, textShadow: "0 2px 4px rgba(0,0,0,0.5)" }}
            >
              {t('welcome')} DZ-SafeSpeech
            </Typography>
            <Typography 
              variant="h5" 
              align="center"
              fontWeight="bold"
              sx={{ mb: 2, color: "#20E5F6", textShadow: "0 2px 4px rgba(0,0,0,0.5)" }}
            >
              {t('title')}
            </Typography>
            
            <Typography 
              variant="subtitle1" 
              align="center"
              color="text.secondary"
              sx={{ mb: 5 }}
            >
            </Typography>
          </motion.div>

          <Card 
            sx={{
              mb: 4,
              transition: "all 0.3s ease-in-out",
              backgroundColor: "#1A1A1A",
              "&:hover": {
                boxShadow: "0 12px 48px rgba(32, 229, 246, 0.2)"
              }
            }}
          >
            <CardContent sx={{ p: 3 }}>
              <TextField
                label={t('textFieldLabel')}
                multiline
                rows={6}
                variant="outlined"
                value={text}
                onChange={(e) => setText(e.target.value)}
                fullWidth
                sx={{ mb: 3 }}
              />
              
              <Box display="flex" justifyContent="center">
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleAnalyze}
                  disabled={loading}
                  size="large"
                  sx={{
                    minWidth: 180,
                    transition: "all 0.3s ease",
                    background: "linear-gradient(135deg, #2F509F 0%, #20E5F6 100%)",
                    "&:hover": {
                      transform: "translateY(-2px)",
                      boxShadow: "0 6px 20px rgba(32, 229, 246, 0.4)",
                      background: "linear-gradient(135deg, #3A61BD 0%, #57EEFF 100%)",
                    }
                  }}
                >
                  {loading ? (
                    <CircularProgress size={24} color="inherit" />
                  ) : (
                    t('analyzeButton')
                  )}
                </Button>
              </Box>
            </CardContent>
          </Card>

          {analysis && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              <ResultCard isHateSpeech={isHateSpeech}>
                <Box 
                  sx={{
                    p: 2.5,
                    textAlign: "center",
                    bgcolor: isHateSpeech ? "rgba(255, 82, 82, 0.15)" : "rgba(76, 175, 80, 0.15)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 1.5
                  }}
                >
                  {isHateSpeech ? (
                    <WarningAmber color="error" fontSize="large" />
                  ) : (
                    <CheckCircle color="success" fontSize="large" />
                  )}
                  <Typography 
                    variant="h5" 
                    fontWeight="bold" 
                    color={isHateSpeech ? "error" : "success"}
                  >
                    {analysis}
                  </Typography>
                  
                  <Tooltip title={copied ? t('copiedTooltip') : t('copyTooltip')}>
                    <IconButton 
                      size="small" 
                      onClick={handleCopyResults}
                      sx={{ ml: 'auto', color: "rgba(255,255,255,0.7)" }}
                    >
                      <ContentCopy fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </Box>

                {isHateSpeech && (
                  <>
                    <Divider />
                    <Box p={3}>
                      <Box 
                        sx={{
                          display: 'grid',
                          gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' },
                          gap: 3,
                          mb: 3
                        }}
                      >
                        {/* Category Section */}
                        <Paper 
                          elevation={0} 
                          sx={{
                            p: 2.5,
                            bgcolor: "rgba(47, 80, 159, 0.15)",
                            borderRadius: 3,
                            height: '100%',
                            display: 'flex',
                            flexDirection: 'column'
                          }}
                        >
                          <SectionHeader 
                            icon={<Category sx={{ color: "#2F509F" }} />}
                            title={t('categoryTitle')} 
                            tooltip={t('categoryTooltip')}
                          />
                          <Box 
                            sx={{
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              flexGrow: 1
                            }}
                          >
                            <Chip 
                              label={category}
                              color="primary"
                              sx={{
                                fontSize: '1.1rem',
                                py: 2.5,
                                px: 1,
                                borderRadius: 3,
                                backgroundColor: "#2F509F",
                                color: "#FFFFFF"
                              }}
                            />
                          </Box>
                        </Paper>

                        {/* Hate Percentage Section */}
                        <Paper 
                          elevation={0} 
                          sx={{
                            p: 2.5,
                            bgcolor: "rgba(255, 82, 82, 0.15)",
                            borderRadius: 3,
                            height: '100%',
                            display: 'flex',
                            flexDirection: 'column'
                          }}
                        >
                          <SectionHeader 
                            icon={<BarChart color="error" />}
                            title={t('hateContentTitle')} 
                            tooltip={t('hateContentTooltip')}
                            />
                            <Box 
                              sx={{
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                justifyContent: 'center',
                                flexGrow: 1
                              }}
                            >
                              <Typography 
                                variant="h4" 
                                fontWeight="bold"
                                color={
                                  hatePercentage > 70 ? 'error.light' : 
                                  hatePercentage > 40 ? 'error.main' : 
                                  hatePercentage > 20 ? 'warning.main' : 'secondary.main'
                                }
                              >
                                {hatePercentage}%
                              </Typography>
                              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                                {t('ofTextContains')}
                              </Typography>
                            </Box>
                          </Paper>
                        </Box>
  
                        {/* Confidence Chart */}
                        <Paper
                          elevation={0}
                          sx={{
                            p: 2.5,
                            bgcolor: "rgba(32, 229, 246, 0.15)",
                            borderRadius: 3,
                            mb: 3
                          }}
                        >
                          <SectionHeader 
                            icon={<PieChart sx={{ color: "#20E5F6" }} />}
                            title={t('confidenceTitle')}
                            tooltip={t('confidenceTooltip')}
                          />
                          <DoughnutChartComp
                            confidenceData={confidenceData}
                            labels={[t('hateContent'), t('normalContent')]}
                            colors={["#FF5252", "#20E5F6"]} 
                          />
                        </Paper>
                        
                        {/* Explanation */}
                        <Paper 
                          elevation={0} 
                          sx={{
                            p: 2.5,
                            bgcolor: "rgba(255, 255, 255, 0.05)",
                            borderRadius: 3,
                            maxHeight: "300px",
                            overflowY: "auto",
                            mb: 3
                          }}
                        >
                          <SectionHeader 
                            icon={<FormatQuote sx={{ color: "#20E5F6" }} />}
                            title={t('explanationTitle')} 
                            tooltip={t('explanationTooltip')}
                          />
                          
                          {explanation ? (
                            <Typography 
                              variant="body1" 
                              sx={{
                                p: 1,
                                borderRadius: 1,
                                bgcolor: 'rgba(255, 255, 255, 0.05)',
                                color: "#FFFFFF"
                              }}
                            >
                              {explanation}
                            </Typography>
                          ) : (
                            <Typography 
                              variant="body2" 
                              color="text.secondary"
                              sx={{
                                p: 2,
                                textAlign: 'center',
                                fontStyle: 'italic'
                              }}
                            >
                              {t('noExplanation')}
                            </Typography>
                          )}
                        </Paper>
                        
                        {/* Highlighted Text */}
                        <Paper 
                          elevation={0} 
                          sx={{
                            p: 2.5,
                            bgcolor: "rgba(47, 80, 159, 0.15)",
                            borderRadius: 3
                          }}
                        >
                          <SectionHeader 
                            icon={<WarningAmber sx={{ color: "#FF5252" }} />}
                            title={t('highlightedTextTitle')} 
                            tooltip={t('highlightedTextTooltip')}
                          />
                          <Box sx={{ 
                            backgroundColor: "rgba(20, 19, 19, 0.6)",
                            p: 2, 
                            borderRadius: 2,
                            color: "#FFFFFF" 
                          }}>
                            <HateHighlightText htmlText={highlightedHTML} />
                          </Box>
                        </Paper>
                      </Box>
                      <HateStats percentage={hatePercentage} />
                      
                      {/* World Map */}
                      {countries && countries.length > 0 && (
      
                          <CountryHighlightMap
                            title={t('geographicDistributionTitle') || "Geographic Distribution"}
                            countryNames={countries}
                            highlightColor="#20E5F6" 
                            baseColor="#2F509F"
                            backgroundColor="#141313"
                          />
                      )}
                    </>
                  )}
                </ResultCard>
              </motion.div>
            )}
          </Container>
        </GradientBackground>
      </ThemeProvider>
    );
  };
  
  export default Homepage;