import React from 'react';
import Homepage from './pages/Homepage';
import { LanguageProvider } from './contexts/LanguageContext';
import Header from './components/Header';

function App() {
  return (
    <LanguageProvider>
      <Header />
      <Homepage />
    </LanguageProvider>
  );
}

export default App;
